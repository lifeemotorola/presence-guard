# Build with GitHub Actions

Experimental build setup for Windows **x64** and OBS 33.0.1. It has not been run or tested. GitHub Actions will build the DLL on GitHub's Windows runner; you do not need Visual Studio on your computer. A GitHub account is required. Actions usage may be subject to GitHub account limits. Do not use for ARM64 OBS.

1. Create a new empty GitHub repository (public or private). Extract this ZIP first.
2. Upload the **contents** of this folder to the root of the repository, including the hidden `.github` directory. The easiest way in VS Code is to open the extracted folder, initialize Git, commit, then use **Publish to GitHub**. Ensure `.github/workflows/windows.yml` appears on GitHub; do not upload the ZIP itself. The branch must be named `main`, or run the workflow manually.
3. In GitHub open **Actions** → **Build Windows x64 OBS plugin** → **Run workflow**. It may start automatically after a push. Approve Actions if prompted.
4. Wait for a green check. Open the run → **Artifacts** → download `obs-local-ai-windows-x64`. If it fails, open the failed step and share its error log; no DLL is available until the run succeeds.
5. Extract the artifact, close OBS, and in the extracted folder run PowerShell: `powershell -ExecutionPolicy Bypass -File .\Install.ps1`. Restart OBS and add **Local AI Auto Frame** to a compatible async camera source. See limitations below.

The build downloads OBS and OpenCV dependencies and copies the OpenCV runtime DLL. This pipeline is unverified, may need fixes, and a successful build does not prove runtime compatibility or GPU acceleration. Inspect OBS logs for load failures. The CPU backend is default. OBS camera frames must be BGRA, BGRX or RGBA; other formats pass through. See README in the original project for limitations. Scripts install only to the user OBS plugin folder. OpenCV and OBS have separate licenses; review before distributing artifacts.
